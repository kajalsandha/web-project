$(document).ready(function() {

    //Event listener for "Add Task" button 

    $('#add_New_Task_Btn').click(function() {

        // Get the task name from the input field

        var taskText = $('#task_Input').val();

        // Check if the input is not empty

        if (taskText.trim() !== '') {

            // Append a new task to the task list

            $('#task_List').append('<li><input type="checkbox" class="task_Checkbox"><span>' + taskText + '</span><button class="delete_Btn">Delete</button></li>');

            // Clear the input field after adding the task
            
            $('#task_Input').val(' ');
        
        }
    
    });

    // Event Listener for Mark task as completed
    
    $(document).on('change', '.task_Checkbox', function() {
    
        // Toggle the 'completed' class for the task's text
    
        $(this).siblings('span').toggleClass('completed');
    
    });

   // Event listener for delete buttons
    
   $(document).on('click', '.delete_Btn', function() {
   
       // Remove the parent task item when the delete button is clicked
   
        $(this).parent().remove();
   
    });

    // Event listener for the "Mark All" button

    $('#mark_All_Btn').click(function() {

        // Set all task checkboxes to checked

        $('.task_Checkbox').prop('checked', true);

        // Add the 'completed' class to all task texts

        $('span').addClass('completed');

    });

    // Event listener for the "Clear Completed" button

    $('#clear_Completed_Task_Btn').click(function() {

        // Remove all completed tasks from the list

        $('.completed').parent().remove();

    });
    
});
