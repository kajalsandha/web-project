
let signUp_toggle_Btn = document.getElementById("signUp_toggle_Btn"); // var for sign up toggle button
let signIn_toggle_Btn = document.getElementById("signIn_toggle_Btn");
let name = document.getElementById("name"); 
let title = document.getElementById("title");
let forget_pass = document.getElementById("forget_pass");
let checkbox = document.getElementById("checkbox");
let email = document.getElementById("email");
let password = document.getElementById("password");



signIn_toggle_Btn.onclick = function () {

    $(document).ready(function () {

        $("#name").hide(); // this function is used to hide the name field from sign in form
    });

    document.login_page.name.value = " "; 
    title.innerHTML = "Sign In"; // change title  text into from Sign up to Sign In
    signUp_toggle_Btn.classList.add("hidden"); //  add hidden class style to signup button
    signIn_toggle_Btn.classList.remove("hidden"); // remove hidden class style to signup button
    forget_pass.style.visibility = "visible"; //visible the forget password text from Sign in form
    checkbox.style.visibility = "visible"; //visible  the Checkbox from Sign in form

}


signUp_toggle_Btn.onclick = function () {

    $(document).ready(function () {
        $("#name").show(); // this function is used to show the name field from sign up form
    });
    

    title.innerHTML = "Sign Up"; // change title  text into from  Sign In to Sign up 
    signIn_toggle_Btn.classList.add("hidden"); //  add hidden class style to signin button
    signUp_toggle_Btn.classList.remove("hidden"); // remove hidden class style to signin button
    forget_pass.style.visibility = "hidden"; //hide  the forget password text from sign up form
    checkbox.style.visibility = "hidden"; //hide  the Checkbox from sign up form
    document.signUp_toggle_Btn.onclick = Boolean(true);

}

function submitFunction() {
   
        alert("Thank you for joining us");
    
    }
    




